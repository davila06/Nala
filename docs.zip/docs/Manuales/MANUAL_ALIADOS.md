# Manual de Aliados — PawTrack CR

**Versión:** 3.0
**Audiencia:** Organizaciones aliadas verificadas y solicitantes  
**Última actualización:** 2026-09-09

> Rol del sistema: `Ally`. Los refugios aprobados (`AllyType = Shelter`) usan
> además el flujo de adopciones descrito al final de este manual.

---

## Tabla de contenidos

1. [¿Qué es un aliado PawTrack?](#1-qué-es-un-aliado-pawtrack)
2. [Tipos de aliados](#2-tipos-de-aliados)
3. [Cómo postularse](#3-cómo-postularse)
4. [Estados de la solicitud](#4-estados-de-la-solicitud)
5. [Bandeja operativa — aliados verificados](#5-bandeja-operativa--aliados-verificados)
6. [Confirmar acciones de búsqueda](#6-confirmar-acciones-de-búsqueda)
7. [Preguntas frecuentes](#7-preguntas-frecuentes)

---

## 1. ¿Qué es un aliado PawTrack?

Un aliado PawTrack CR es una organización o entidad que colabora activamente con la red de recuperación de mascotas. Una vez verificada, tu organización:

- Recibe **alertas operativas** sobre mascotas perdidas dentro de tu zona de cobertura declarada.
- Puede **confirmar acciones de búsqueda** realizadas en tu área.
- Contribuye a la red de apoyo comunitario que aumenta las probabilidades de reunificación.

La participación es voluntaria. No se requiere pago ni membresía.

---

## 2. Tipos de aliados

Al postularte debes seleccionar el tipo que mejor describe a tu organización:

| Tipo                      | Descripción                                                                                                  |
| ------------------------- | ------------------------------------------------------------------------------------------------------------ |
| **Veterinaria**           | Clínica o consultorio veterinario que puede recibir mascotas encontradas o brindar atención de emergencia    |
| **Refugio**               | Albergue o refugio de animales que puede custodiar mascotas temporalmente                                    |
| **Comercio pet-friendly** | Establecimiento comercial abierto al público que acepta mascotas y puede ser punto de referencia comunitaria |
| **Seguridad privada**     | Empresa o personal de seguridad con cobertura en zonas residenciales o comerciales                           |
| **Municipalidad**         | Institución municipal con capacidad de apoyo logístico o comunicación oficial                                |

---

## 3. Cómo postularse

### 3.1 Requisito previo

Necesitas tener una cuenta registrada en PawTrack CR con rol habitual (propietario). El rol de Aliado se asigna después de la aprobación.

### 3.2 Acceder al formulario

1. Inicia sesión en `https://pawtrack.cr`.
2. El enlace al panel de aliados **solo aparece en tu navegación una vez que el equipo PawTrack te ha dado acceso** al módulo. Si no ves el enlace, no tienes acceso habilitado aún.
3. Accede directamente a `/allies/panel`.

### 3.3 Completar el formulario de postulación

El formulario pide los siguientes datos:

| Campo                 | Descripción                                                                                                |
| --------------------- | ---------------------------------------------------------------------------------------------------------- |
| **Organización**      | Nombre oficial de tu organización (ej. "Fundación Huellas Seguras")                                        |
| **Tipo de aliado**    | Selecciona de la lista desplegable (ver sección 2)                                                         |
| **Zona de cobertura** | Nombre descriptivo del área que tu equipo puede cubrir (ej. "Barrio Escalante, San José")                  |
| **Área de cobertura** | Mapa interactivo donde seleccionas el punto central y el radio en metros que tu organización puede atender |

### 3.4 Enviar la solicitud

Una vez completados todos los campos, haz clic en **Enviar solicitud**. Serás redirigido a la vista de estado de tu postulación.

> La revisión es realizada manualmente por el equipo PawTrack y toma entre **1 y 2 días hábiles**.

---

## 4. Estados de la solicitud

Después de enviar tu postulación, el panel muestra tu estado actual:

| Estado                         | Descripción                                          | Qué hacer                                                                        |
| ------------------------------ | ---------------------------------------------------- | -------------------------------------------------------------------------------- |
| **Pendiente de revisión**      | Tu solicitud fue recibida y está en cola de revisión | Esperar. Recibirás una notificación cuando sea procesada                         |
| **Verificado**                 | Tu organización fue aprobada como aliado             | Tienes acceso a la bandeja operativa (sección 5)                                 |
| **Requiere nueva postulación** | Tu solicitud anterior fue rechazada                  | Puedes enviar una nueva solicitud con información corregida desde el mismo panel |

---

## 5. Bandeja operativa — aliados verificados

Una vez que tu organización esté verificada, el panel de aliados muestra la **bandeja operativa** en lugar del formulario de postulación.

### 5.1 Qué son las alertas operativas

Cada vez que se reporta una mascota perdida dentro de tu zona de cobertura declarada, el sistema genera una alerta operativa para tu organización. Esta alerta incluye:

- **Título** — descripción corta del caso (ej. "Perro golden perdido, Escazú")
- **Cuerpo** — información relevante del aviso
- **Fecha y hora** — cuándo se generó la alerta (horario de Costa Rica)

### 5.2 Contador de alertas activas

En la esquina superior derecha de la bandeja aparece el número de alertas activas que aún no han tenido una acción confirmada por tu organización.

### 5.3 Estado de cada alerta

Cada alerta puede estar en uno de dos estados:

| Estado                | Indicador visual                                      |
| --------------------- | ----------------------------------------------------- |
| **Sin confirmar**     | Botón "Ya buscamos en nuestra área" visible           |
| **Acción confirmada** | Badge verde "Acción confirmada" — el botón desaparece |

---

## 6. Confirmar acciones de búsqueda

### 6.1 ¿Cuándo confirmar?

Confirma una alerta cuando tu equipo ya tomó alguna acción concreta en el área: patrulló la zona, preguntó a vecinos, revisó instalaciones, colocó un cartel, etc.

### 6.2 Cómo confirmar

1. En la bandeja operativa, localiza la alerta correspondiente.
2. Haz clic en **Ya buscamos en nuestra área**.
3. El estado de la alerta cambia a "Acción confirmada" automáticamente.

### 6.3 Efecto de la confirmación

La confirmación:

- Queda registrada en el sistema con fecha y hora.
- Notifica al dueño de la mascota que una organización aliada buscó activamente en esa zona.
- No cierra el caso — el caso permanece activo hasta que el dueño lo marque como reunido.

> **Importante:** Solo puedes confirmar una alerta una vez. No hay forma de deshacer la confirmación desde el panel.

### 6.4 Alertas sin acciones disponibles

Si una alerta ya fue confirmada por tu organización, muestra el badge verde y no tiene botón de acción. Esto es normal.

---

## 7. Preguntas frecuentes

**¿Puedo cambiar el área de cobertura después de ser aprobado?**  
No en la versión actual del panel. Si necesitas actualizar tu cobertura, contacta al equipo PawTrack.

**¿Recibo notificaciones fuera de la plataforma cuando hay una nueva alerta operativa?**  
El envío de alertas push a aliados está previsto. Consulta la configuración de notificaciones en el centro de notificaciones de la plataforma para habilitar los avisos que estén disponibles.

**¿Qué pasa si mi solicitud fue rechazada?**  
El panel mostrará el estado "Requiere nueva postulación". Puedes reenviar el formulario con información más completa o corregida. No hay límite de intentos.

**¿Cuántas alertas puedo tener activas al mismo tiempo?**  
No hay límite. Recibirás todas las alertas que el sistema genere dentro de tu zona de cobertura declarada.

**¿Puedo pertenecer a la red de aliados siendo un individuo y no una organización?**  
El programa de aliados está orientado a organizaciones. Los individuos pueden contribuir a través del modo voluntario de custodia temporal (Fosters) desde su perfil de usuario.

**¿Mis datos de contacto son visibles para los dueños de las mascotas?**  
El nombre de la organización y la zona de cobertura pueden ser visibles en el contexto de los casos. Los datos de contacto individuales de tu cuenta no se exponen públicamente.

---

## 8. Módulo de Adopciones (Shelter)

> Solo disponible para aliados con AllyType = Shelter y estado Verified.

### 8.1 Publicar un animal en adopción

1. Ir a **/shelter/publicar** desde el panel de aliados.
2. Completar el formulario:
   - **Información básica**: nombre, especie, raza, tamaño, categoría de edad.
   - **Historia y personalidad**: texto libre hasta 2,000 caracteres.
   - **Características**: vacunado, castrado, microchip, OK con niños/perros/gatos, necesita patio.
   - **Zona de referencia**: texto descriptivo (ej. "Escazú, San José") — NO se expone la dirección exacta del shelter.
3. Hacer clic en **Publicar animal**.
4. Subir fotos desde el panel del shelter (hasta 5 fotos por animal).

> **Estado base / directorio gratuito (`ShelterBasic`):** máximo 5 animales activos simultáneamente.
> **Plan activo (`ShelterPlus` ₡8,000/mes):** animales ilimitados + ferias de adopción + pin destacado en el mapa.

### 8.2 Gestionar solicitudes de adopción

En **/shelter/animales/:id/aplicaciones**:

- Ver todas las solicitudes recibidas con la nota personal de cada aplicante.
- **Aprobar**: el animal cambia a estado "En proceso" y el adoptante recibe una notificación.
- **Rechazar**: el adoptante recibe una notificación con la nota de respuesta (opcional).
- Cuando la entrega física se realiza, usar **"Marcar como adoptado"** en el panel principal.

### 8.3 Crear ferias de adopción (ShelterPlus)

En **/shelter/dashboard**, pestaña "Ferias":

1. Clic en **Crear nueva feria**.
2. Completar: título, descripción, lugar (nombre del lugar), coordenadas GPS, fecha de inicio y fin.
3. Seleccionar qué animales estarán presentes.
4. El sistema envía alertas push geofenceadas a usuarios dentro de 10 km del lugar.

### 8.4 Estados del animal

| Estado         | Descripción                                                             |
| -------------- | ----------------------------------------------------------------------- |
| **Disponible** | Visible en el directorio; acepta solicitudes                            |
| **En proceso** | Una solicitud fue aprobada; no acepta nuevas solicitudes                |
| **Adoptado**   | Cerrado exitosamente; sale del directorio activo                        |
| **Pausado**    | Temporalmente oculto del directorio (ej. el animal está en tratamiento) |
| **Removido**   | Borrado lógico; no aparece en ningún listado                            |
