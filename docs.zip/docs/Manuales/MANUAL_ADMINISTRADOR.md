# Manual de Administrador — PawTrack CR

**Versión:** 3.0
**Audiencia:** Administradores del sistema  
**Última actualización:** 2026-09-09

> El rol `Admin` tiene acceso global y toda operación sensible debe seguir la
> matriz de autorización de [API_AUTHORIZATION_MATRIX.md](../API_AUTHORIZATION_MATRIX.md).

---

## Tabla de contenidos

1. [Acceso al panel de administración](#1-acceso-al-panel-de-administración)
2. [Tabs disponibles en el panel](#2-tabs-disponibles-en-el-panel)
3. [Gestión de Aliados](#3-gestión-de-aliados)
4. [Gestión de Clínicas Veterinarias](#4-gestión-de-clínicas-veterinarias)
5. [Gestión de Tiendas de Mascotas](#5-gestión-de-tiendas-de-mascotas)
6. [Vallas Publicitarias](#6-vallas-publicitarias)
7. [Suscripciones y Planes](#7-suscripciones-y-planes)
8. [Promociones y Descuentos](#8-promociones-y-descuentos)
9. [Bundles GPS](#9-bundles-gps)
10. [Preguntas frecuentes](#10-preguntas-frecuentes)

Las pestañas **Adopciones**, **Bienestar**, **Proveedores** y **Funnel** se
encuentran en el panel actual aunque sus operaciones detalladas dependen de los
permisos del endpoint y de la evidencia disponible.

---

## 1. Acceso al panel de administración

### 1.1 Requisitos de rol

Exclusivo para cuentas con rol **Admin**. Si intentas acceder sin ese rol, el sistema te redirige al Dashboard.

### 1.2 Cómo acceder

1. Inicia sesión en `https://pawtrack.cr`.
2. Navega a `/admin` o usa el enlace **Panel de administración** en la barra de navegación.

---

## 2. Tabs disponibles en el panel

| Tab               | Función                                                                    |
| ----------------- | -------------------------------------------------------------------------- |
| **Aliados**       | Revisar/aprobar solicitudes de aliados                                     |
| **Clínicas**      | Gestionar clínicas veterinarias                                            |
| **Suscripciones** | Ver y gestionar planes de todos los usuarios                               |
| **Bundles**       | Bundles GPS on-demand                                                      |
| **Promociones**   | Códigos de descuento y promociones                                         |
| **Tiendas**       | Aprobar/rechazar tiendas pendientes de registro                            |
| **Vallas** 🆕     | Crear, editar, activar/pausar vallas publicitarias                         |
| **CollarTags**    | Inventario y métricas de collares GPS (registrar, marcar vendido, revocar) |
| **Adopciones**    | Estadísticas y moderación administrativa de publicaciones y solicitudes    |
| **Bienestar**     | Triage, severidad, asignación, evidencia y cierre de casos                 |
| **Proveedores**   | Verificaciones, operaciones e incidentes de proveedores                    |
| **Funnel**        | Métricas de producto y export CSV agregado sin PII                         |

---

## 3. Gestión de Aliados

### 3.1 Revisar solicitudes pendientes

En el tab **Aliados**, verás la lista de perfiles pendientes de verificación con:

- Nombre del aliado
- Tipo de organización
- Zona de cobertura declarada
- Fecha de solicitud

### 3.2 Acciones disponibles

- **Aprobar** → El aliado recibe acceso completo al Panel de Aliado y sus alertas quedan activas.
- **Rechazar** → La solicitud se descarta. El usuario permanece con rol Owner.

---

## 4. Gestión de Clínicas Veterinarias

### 4.1 Solicitudes pendientes

En el tab **Clínicas**, verás clínicas en estado `Pending`:

- Nombre de la clínica
- Dirección y teléfono
- Email de contacto
- Fecha de solicitud

### 4.2 Activar suscripción de clínica

1. Selecciona la clínica → **Activar**.
2. Elige el tier activo: `ClinicPlus` o `ClinicPartner`.
3. La clínica recibe acceso inmediato al portal veterinario.

> El registro y el directorio son la entrada gratuita. Los tiers comerciales
> vigentes son `ClinicPlus` y `ClinicPartner`; `ClinicBasic` no es un plan de
> compra activo.

### 4.3 Gestionar API keys

Las clínicas con plan ClinicPartner pueden tener API keys para integración externa. El administrador puede:

- Ver keys activas
- Revocar una key comprometida
- Generar una nueva key

### 4.4 Verificación para pasaportes SENASA-ready

Activar una clínica no basta para que pueda emitir pasaportes veterinarios digitales. Para habilitar emisión SENASA-ready:

1. Confirma que la clínica está `Active`.
1. Confirma que tiene suscripción `ClinicPartner` activa.
1. Revisa que la clínica haya subido documento privado de respaldo.
1. Verifica la licencia SENASA declarada y registra vencimiento.
1. Aprueba o rechaza la verificación con motivo.
1. Revisa cada veterinario pendiente, su licencia y documento.
1. Autoriza, rechaza o suspende veterinarios según corresponda.

El sistema bloquea emisión si falta cualquiera de estas condiciones. La verificación pública del pasaporte no muestra datos privados del dueño ni descarga el PDF completo.

Las revisiones se administran desde la pestaña **Verificación** del panel admin. Todo cambio de estado y descarga documental queda auditado.

### 4.5 Revocación de certificados

Un certificado o pasaporte debe revocarse cuando fue emitido con error material, licencia incorrecta, veterinario no autorizado, datos sanitarios dudosos o solicitud legítima de corrección. Toda revocación requiere motivo y queda auditada. La verificación pública seguirá respondiendo, pero mostrará estado **Revocado**.

### 4.6 Conflictos de microchip

La pestaña **Microchips** muestra mascotas cuyo microchip leído por una clínica no coincide con el declarado. El administrador debe revisar la evidencia, confirmar el chip correcto o revocar la verificación con motivo. Toda resolución queda auditada.

### 4.7 Casos de bienestar y reportes institucionales

La pestaña **Bienestar** permite revisar casos recibidos, iniciar triage,
ajustar severidad, asignar una organización, derivar con motivo y cerrar con
resultado. La evidencia se descarga únicamente mediante endpoints autenticados.

Desde `/reportes-institucionales` los roles autorizados pueden consultar el
catálogo, solicitar previews/exports y descargar archivos completados. Los
exports son agregados y `SENASA-ready`; no son envíos oficiales a SENASA.

La ruta `/nala` muestra overview, tendencias y capas geográficas generalizadas.
No se deben publicar ubicaciones exactas, evidencia, reportantes ni datos de
propietarios. Para incidentes de integridad, expiración o acceso indebido,
seguir `docs/RUNBOOK_REPORTES_INSTITUCIONALES.md`.

---

## 5. Gestión de Tiendas de Mascotas

### 5.1 Flujo de aprobación

Cuando un dueño de tienda completa el registro en `/tienda/registro`, la tienda queda en estado `Pending`.

En el tab **Tiendas**:

1. Ver lista de tiendas pendientes (nombre, dirección, coordenadas, email de contacto).
2. **Aprobar** → La tienda aparece en el mapa y directorio públicos en estado `Active`.
3. **Rechazar** → La tienda queda en estado `Suspended`.

### 5.2 Tiers de tienda

| Tier           | Capacidades                                                |
| -------------- | ---------------------------------------------------------- |
| `StoreBasic`   | Estado base gratuito: catálogo visible, sin pedidos in-app |
| `StorePlus`    | Catálogo + pedidos in-app + SINPE                          |
| `StorePartner` | Todo StorePlus + analytics + posición prioritaria          |

> `StoreBasic` no es el plan pagado principal del producto actual; es un nivel de registro/directorio gratuito.

Para cambiar el tier de una tienda, usa la suscripción (tab **Suscripciones**) y asigna el tier correspondiente al userId del dueño de la tienda.

---

## 6. Vallas Publicitarias

El sistema de vallas permite mostrar anuncios en 4 ubicaciones de la app.

### 6.1 Crear una valla

1. Tab **Vallas** → **+ Nueva valla**.
2. Completa:
   - **Título** (máx. 120 chars) — texto principal del anuncio
   - **Descripción** (máx. 300 chars) — texto secundario opcional
   - **Ubicación (Placement):**
     - `Map` — Overlay en el mapa público
     - `Dashboard` — Entre tarjetas de mascotas
     - `Directory` — Top del directorio de tiendas/clínicas
     - `Feed` — Sobre la lista de mascotas perdidas
   - **Inicio y Fin** — ventana de actividad del anuncio
   - **CTA Texto** — etiqueta del botón (ej: "Ver más →")
   - **CTA URL** — URL destino (solo HTTPS o mismo dominio)
   - **Prioridad** (0-100) — si hay varias vallas activas, la de mayor prioridad se muestra primero

3. Click **Crear valla** → la valla queda en estado `Draft`.

### 6.2 Subir imagen

Una vez creada la valla:

1. Click **📷 Imagen** en la fila de la valla.
2. Selecciona la imagen (JPEG, PNG o WebP, máx. 5MB).
3. La imagen se redimensiona automáticamente a 1200px y se guarda en Blob Storage.

### 6.3 Activar / Pausar / Expirar

| Acción      | Estado resultante | Efecto                                           |
| ----------- | ----------------- | ------------------------------------------------ |
| **Activar** | `Active`          | Aparece en la app dentro de la ventana de fechas |
| **Pausar**  | `Paused`          | Desaparece temporalmente; puede reactivarse      |
| **Expirar** | `Expired`         | Permanente; no se puede reactivar                |

### 6.4 Comportamiento en la app

- Solo aparece **1 valla por placement** en cada momento (la de mayor prioridad).
- El usuario puede **cerrar** la valla; no vuelve a aparecer en esa sesión (sessionStorage).
- Si hay múltiples vallas activas para el mismo placement, al cerrar una aparece la siguiente en prioridad.
- Máximo 5 vallas activas por placement para no saturar la UI.

---

## 7. Suscripciones y Planes

### 7.1 Ver suscripciones activas

Tab **Suscripciones** → lista de todos los usuarios con suscripción activa:

- Email del usuario
- Plan actual
- Fecha de activación
- Referencia SINPE del pago

### 7.2 Activar suscripción manualmente

Para activar un plan después de verificar el pago SINPE:

1. Localiza la suscripción en estado `PendingPayment` o `PaymentReported`.
2. Click **Activar**.
3. El usuario recibe acceso inmediato al plan.

### 7.3 Tiers disponibles

| Tier interno      | Plan visible     | Precio real del backend |
| ----------------- | ---------------- | ----------------------- |
| `Free`            | Explorador       | ₡0                      |
| `UserPlus`        | Plus             | ₡2,990/mes              |
| `UserFamilia`     | Familia          | ₡4,990/mes              |
| `StorePlus`       | Tienda Plus      | ₡12,000/mes             |
| `StorePartner`    | Tienda Partner   | ₡25,000/mes             |
| `ClinicPlus`      | Clínica Plus     | ₡15,000/mes             |
| `ClinicPartner`   | Clínica Partner  | ₡35,000/mes             |
| `ShelterPlus`     | Refugio Plus     | ₡8,000/mes              |
| `MuniBasica`      | Municipal Básica | ₡150,000/año            |
| `MuniFull`        | Municipal Full   | ₡300,000/año            |
| `MuniRedRegional` | Red Regional     | ₡500,000/año            |

> Los nombres `ClinicBasic`, `StoreBasic` y `ShelterBasic` aparecen como estados base o de directorio; no son la definición comercial activa en la implementación actual.

### 7.4 Administrar planes y precios

El tab **Planes y precios** del panel admin permite consultar, crear, editar y desactivar los planes comerciales. Solo usuarios con rol `Admin` pueden acceder.

- Los tiers son identificadores estables y no se pueden cambiar al editar un plan.
- Cada plan debe tener al menos un precio positivo mensual o anual.
- La edición usa control de versión; si otro administrador modificó el plan, la operación se rechaza para evitar sobrescribir cambios.
- La desactivación es lógica para conservar el historial de suscripciones existentes.
- La creación de nuevas suscripciones consulta este catálogo administrado; los cambios de precio no modifican suscripciones ya creadas.

API administrativa equivalente: `GET/POST /api/admin/subscription-plans`, `GET/PUT/DELETE /api/admin/subscription-plans/{id}`.

---

## 8. Promociones y Descuentos

Tab **Promociones** → gestión de códigos de descuento:

- **Crear código**: define el porcentaje de descuento, fechas de vigencia y usos máximos.
- **Desactivar**: desactiva un código antes de su expiración.
- **Ver redemptions**: qué usuarios usaron cada código.

---

## 9. Bundles GPS

Tab **Bundles** → pedidos de Bundle GPS:

- Lista de pedidos de bundle (hardware collar GPS + suscripción).
- Estado: `PendingPayment` → `Active`.
- Activar manualmente después de verificar el pago.

---

## 9.1 Inventario de Collar Tags

Tab **CollarTags** → inventario y métricas de collares GPS:

- Métricas: total de tags, activos, vendidos, revocados.
- Registrar tags nuevos (individual o bulk import).
- Marcar como vendido / revocar un tag.
- Buscar por número de serie.

---

## 10. Preguntas frecuentes

**¿Cómo desbloqueo una cuenta con demasiados intentos fallidos?**  
Ver `RUNBOOK_OPERACIONES.md §12`. Requiere acceso directo a la base de datos.

**¿Puedo cambiar el rol de un usuario directamente?**  
No desde la UI; se requiere acceso a la DB. Los roles se asignan al crear el perfil de aliado, clínica o tienda.

**¿Qué pasa si apruebo una tienda por error?**  
Cambia su estado a `Suspended` via la API admin: `PUT /api/admin/stores/{id}/review` con `{ approve: false }`.

**¿Las vallas aparecen para usuarios no autenticados?**  
Sí. El endpoint `GET /api/billboards?placement=X` es público. Esto es intencional para máxima exposición.
